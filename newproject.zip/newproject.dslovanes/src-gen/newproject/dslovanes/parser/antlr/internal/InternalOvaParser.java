package newproject.dslovanes.parser.antlr.internal;

import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.parser.antlr.AbstractInternalAntlrParser;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.parser.antlr.AntlrDatatypeRuleToken;
import newproject.dslovanes.services.OvaGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalOvaParser extends AbstractInternalAntlrParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_ID", "RULE_STRING", "RULE_INT", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'Test'", "'{'", "'}'", "'.'", "'import'", "'.*'", "'datatype'", "'enum'", "'|'", "'='", "'requires'", "'TestCase'", "'on'", "','", "'tests'", "'input'", "'val'", "'verifies'", "'output'"
    };
    public static final int RULE_STRING=5;
    public static final int RULE_SL_COMMENT=8;
    public static final int T__19=19;
    public static final int T__15=15;
    public static final int T__16=16;
    public static final int T__17=17;
    public static final int T__18=18;
    public static final int T__11=11;
    public static final int T__12=12;
    public static final int T__13=13;
    public static final int T__14=14;
    public static final int EOF=-1;
    public static final int RULE_ID=4;
    public static final int RULE_WS=9;
    public static final int RULE_ANY_OTHER=10;
    public static final int T__26=26;
    public static final int T__27=27;
    public static final int T__28=28;
    public static final int RULE_INT=6;
    public static final int T__29=29;
    public static final int T__22=22;
    public static final int RULE_ML_COMMENT=7;
    public static final int T__23=23;
    public static final int T__24=24;
    public static final int T__25=25;
    public static final int T__20=20;
    public static final int T__21=21;

    // delegates
    // delegators


        public InternalOvaParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalOvaParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalOvaParser.tokenNames; }
    public String getGrammarFileName() { return "InternalOva.g"; }



     	private OvaGrammarAccess grammarAccess;

        public InternalOvaParser(TokenStream input, OvaGrammarAccess grammarAccess) {
            this(input);
            this.grammarAccess = grammarAccess;
            registerRules(grammarAccess.getGrammar());
        }

        @Override
        protected String getFirstRuleName() {
        	return "DomainModel";
       	}

       	@Override
       	protected OvaGrammarAccess getGrammarAccess() {
       		return grammarAccess;
       	}




    // $ANTLR start "entryRuleDomainModel"
    // InternalOva.g:64:1: entryRuleDomainModel returns [EObject current=null] : iv_ruleDomainModel= ruleDomainModel EOF ;
    public final EObject entryRuleDomainModel() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleDomainModel = null;


        try {
            // InternalOva.g:64:52: (iv_ruleDomainModel= ruleDomainModel EOF )
            // InternalOva.g:65:2: iv_ruleDomainModel= ruleDomainModel EOF
            {
             newCompositeNode(grammarAccess.getDomainModelRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleDomainModel=ruleDomainModel();

            state._fsp--;

             current =iv_ruleDomainModel; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleDomainModel"


    // $ANTLR start "ruleDomainModel"
    // InternalOva.g:71:1: ruleDomainModel returns [EObject current=null] : ( (lv_elements_0_0= ruleAbstractElement ) )* ;
    public final EObject ruleDomainModel() throws RecognitionException {
        EObject current = null;

        EObject lv_elements_0_0 = null;



        	enterRule();

        try {
            // InternalOva.g:77:2: ( ( (lv_elements_0_0= ruleAbstractElement ) )* )
            // InternalOva.g:78:2: ( (lv_elements_0_0= ruleAbstractElement ) )*
            {
            // InternalOva.g:78:2: ( (lv_elements_0_0= ruleAbstractElement ) )*
            loop1:
            do {
                int alt1=2;
                int LA1_0 = input.LA(1);

                if ( (LA1_0==11||LA1_0==15||(LA1_0>=17 && LA1_0<=18)) ) {
                    alt1=1;
                }


                switch (alt1) {
            	case 1 :
            	    // InternalOva.g:79:3: (lv_elements_0_0= ruleAbstractElement )
            	    {
            	    // InternalOva.g:79:3: (lv_elements_0_0= ruleAbstractElement )
            	    // InternalOva.g:80:4: lv_elements_0_0= ruleAbstractElement
            	    {

            	    				newCompositeNode(grammarAccess.getDomainModelAccess().getElementsAbstractElementParserRuleCall_0());
            	    			
            	    pushFollow(FOLLOW_3);
            	    lv_elements_0_0=ruleAbstractElement();

            	    state._fsp--;


            	    				if (current==null) {
            	    					current = createModelElementForParent(grammarAccess.getDomainModelRule());
            	    				}
            	    				add(
            	    					current,
            	    					"elements",
            	    					lv_elements_0_0,
            	    					"newproject.dslovanes.Ova.AbstractElement");
            	    				afterParserOrEnumRuleCall();
            	    			

            	    }


            	    }
            	    break;

            	default :
            	    break loop1;
                }
            } while (true);


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleDomainModel"


    // $ANTLR start "entryRuleAbstractElement"
    // InternalOva.g:100:1: entryRuleAbstractElement returns [EObject current=null] : iv_ruleAbstractElement= ruleAbstractElement EOF ;
    public final EObject entryRuleAbstractElement() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleAbstractElement = null;


        try {
            // InternalOva.g:100:56: (iv_ruleAbstractElement= ruleAbstractElement EOF )
            // InternalOva.g:101:2: iv_ruleAbstractElement= ruleAbstractElement EOF
            {
             newCompositeNode(grammarAccess.getAbstractElementRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleAbstractElement=ruleAbstractElement();

            state._fsp--;

             current =iv_ruleAbstractElement; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleAbstractElement"


    // $ANTLR start "ruleAbstractElement"
    // InternalOva.g:107:1: ruleAbstractElement returns [EObject current=null] : (this_Test_0= ruleTest | this_Import_1= ruleImport | this_Type_2= ruleType ) ;
    public final EObject ruleAbstractElement() throws RecognitionException {
        EObject current = null;

        EObject this_Test_0 = null;

        EObject this_Import_1 = null;

        EObject this_Type_2 = null;



        	enterRule();

        try {
            // InternalOva.g:113:2: ( (this_Test_0= ruleTest | this_Import_1= ruleImport | this_Type_2= ruleType ) )
            // InternalOva.g:114:2: (this_Test_0= ruleTest | this_Import_1= ruleImport | this_Type_2= ruleType )
            {
            // InternalOva.g:114:2: (this_Test_0= ruleTest | this_Import_1= ruleImport | this_Type_2= ruleType )
            int alt2=3;
            switch ( input.LA(1) ) {
            case 11:
                {
                alt2=1;
                }
                break;
            case 15:
                {
                alt2=2;
                }
                break;
            case 17:
            case 18:
                {
                alt2=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 2, 0, input);

                throw nvae;
            }

            switch (alt2) {
                case 1 :
                    // InternalOva.g:115:3: this_Test_0= ruleTest
                    {

                    			newCompositeNode(grammarAccess.getAbstractElementAccess().getTestParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_Test_0=ruleTest();

                    state._fsp--;


                    			current = this_Test_0;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalOva.g:124:3: this_Import_1= ruleImport
                    {

                    			newCompositeNode(grammarAccess.getAbstractElementAccess().getImportParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_Import_1=ruleImport();

                    state._fsp--;


                    			current = this_Import_1;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 3 :
                    // InternalOva.g:133:3: this_Type_2= ruleType
                    {

                    			newCompositeNode(grammarAccess.getAbstractElementAccess().getTypeParserRuleCall_2());
                    		
                    pushFollow(FOLLOW_2);
                    this_Type_2=ruleType();

                    state._fsp--;


                    			current = this_Type_2;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleAbstractElement"


    // $ANTLR start "entryRuleTest"
    // InternalOva.g:145:1: entryRuleTest returns [EObject current=null] : iv_ruleTest= ruleTest EOF ;
    public final EObject entryRuleTest() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleTest = null;


        try {
            // InternalOva.g:145:45: (iv_ruleTest= ruleTest EOF )
            // InternalOva.g:146:2: iv_ruleTest= ruleTest EOF
            {
             newCompositeNode(grammarAccess.getTestRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleTest=ruleTest();

            state._fsp--;

             current =iv_ruleTest; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleTest"


    // $ANTLR start "ruleTest"
    // InternalOva.g:152:1: ruleTest returns [EObject current=null] : (otherlv_0= 'Test' ( (lv_name_1_0= ruleQualifiedName ) ) otherlv_2= '{' ( (lv_testCases_3_0= ruleTestCase ) )* otherlv_4= '}' ) ;
    public final EObject ruleTest() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        AntlrDatatypeRuleToken lv_name_1_0 = null;

        EObject lv_testCases_3_0 = null;



        	enterRule();

        try {
            // InternalOva.g:158:2: ( (otherlv_0= 'Test' ( (lv_name_1_0= ruleQualifiedName ) ) otherlv_2= '{' ( (lv_testCases_3_0= ruleTestCase ) )* otherlv_4= '}' ) )
            // InternalOva.g:159:2: (otherlv_0= 'Test' ( (lv_name_1_0= ruleQualifiedName ) ) otherlv_2= '{' ( (lv_testCases_3_0= ruleTestCase ) )* otherlv_4= '}' )
            {
            // InternalOva.g:159:2: (otherlv_0= 'Test' ( (lv_name_1_0= ruleQualifiedName ) ) otherlv_2= '{' ( (lv_testCases_3_0= ruleTestCase ) )* otherlv_4= '}' )
            // InternalOva.g:160:3: otherlv_0= 'Test' ( (lv_name_1_0= ruleQualifiedName ) ) otherlv_2= '{' ( (lv_testCases_3_0= ruleTestCase ) )* otherlv_4= '}'
            {
            otherlv_0=(Token)match(input,11,FOLLOW_4); 

            			newLeafNode(otherlv_0, grammarAccess.getTestAccess().getTestKeyword_0());
            		
            // InternalOva.g:164:3: ( (lv_name_1_0= ruleQualifiedName ) )
            // InternalOva.g:165:4: (lv_name_1_0= ruleQualifiedName )
            {
            // InternalOva.g:165:4: (lv_name_1_0= ruleQualifiedName )
            // InternalOva.g:166:5: lv_name_1_0= ruleQualifiedName
            {

            					newCompositeNode(grammarAccess.getTestAccess().getNameQualifiedNameParserRuleCall_1_0());
            				
            pushFollow(FOLLOW_5);
            lv_name_1_0=ruleQualifiedName();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getTestRule());
            					}
            					set(
            						current,
            						"name",
            						lv_name_1_0,
            						"newproject.dslovanes.Ova.QualifiedName");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_2=(Token)match(input,12,FOLLOW_6); 

            			newLeafNode(otherlv_2, grammarAccess.getTestAccess().getLeftCurlyBracketKeyword_2());
            		
            // InternalOva.g:187:3: ( (lv_testCases_3_0= ruleTestCase ) )*
            loop3:
            do {
                int alt3=2;
                int LA3_0 = input.LA(1);

                if ( (LA3_0==22) ) {
                    alt3=1;
                }


                switch (alt3) {
            	case 1 :
            	    // InternalOva.g:188:4: (lv_testCases_3_0= ruleTestCase )
            	    {
            	    // InternalOva.g:188:4: (lv_testCases_3_0= ruleTestCase )
            	    // InternalOva.g:189:5: lv_testCases_3_0= ruleTestCase
            	    {

            	    					newCompositeNode(grammarAccess.getTestAccess().getTestCasesTestCaseParserRuleCall_3_0());
            	    				
            	    pushFollow(FOLLOW_6);
            	    lv_testCases_3_0=ruleTestCase();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getTestRule());
            	    					}
            	    					add(
            	    						current,
            	    						"testCases",
            	    						lv_testCases_3_0,
            	    						"newproject.dslovanes.Ova.TestCase");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop3;
                }
            } while (true);

            otherlv_4=(Token)match(input,13,FOLLOW_2); 

            			newLeafNode(otherlv_4, grammarAccess.getTestAccess().getRightCurlyBracketKeyword_4());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTest"


    // $ANTLR start "entryRuleQualifiedName"
    // InternalOva.g:214:1: entryRuleQualifiedName returns [String current=null] : iv_ruleQualifiedName= ruleQualifiedName EOF ;
    public final String entryRuleQualifiedName() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleQualifiedName = null;


        try {
            // InternalOva.g:214:53: (iv_ruleQualifiedName= ruleQualifiedName EOF )
            // InternalOva.g:215:2: iv_ruleQualifiedName= ruleQualifiedName EOF
            {
             newCompositeNode(grammarAccess.getQualifiedNameRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleQualifiedName=ruleQualifiedName();

            state._fsp--;

             current =iv_ruleQualifiedName.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleQualifiedName"


    // $ANTLR start "ruleQualifiedName"
    // InternalOva.g:221:1: ruleQualifiedName returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (this_ID_0= RULE_ID (kw= '.' this_ID_2= RULE_ID )* ) ;
    public final AntlrDatatypeRuleToken ruleQualifiedName() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token this_ID_0=null;
        Token kw=null;
        Token this_ID_2=null;


        	enterRule();

        try {
            // InternalOva.g:227:2: ( (this_ID_0= RULE_ID (kw= '.' this_ID_2= RULE_ID )* ) )
            // InternalOva.g:228:2: (this_ID_0= RULE_ID (kw= '.' this_ID_2= RULE_ID )* )
            {
            // InternalOva.g:228:2: (this_ID_0= RULE_ID (kw= '.' this_ID_2= RULE_ID )* )
            // InternalOva.g:229:3: this_ID_0= RULE_ID (kw= '.' this_ID_2= RULE_ID )*
            {
            this_ID_0=(Token)match(input,RULE_ID,FOLLOW_7); 

            			current.merge(this_ID_0);
            		

            			newLeafNode(this_ID_0, grammarAccess.getQualifiedNameAccess().getIDTerminalRuleCall_0());
            		
            // InternalOva.g:236:3: (kw= '.' this_ID_2= RULE_ID )*
            loop4:
            do {
                int alt4=2;
                int LA4_0 = input.LA(1);

                if ( (LA4_0==14) ) {
                    alt4=1;
                }


                switch (alt4) {
            	case 1 :
            	    // InternalOva.g:237:4: kw= '.' this_ID_2= RULE_ID
            	    {
            	    kw=(Token)match(input,14,FOLLOW_4); 

            	    				current.merge(kw);
            	    				newLeafNode(kw, grammarAccess.getQualifiedNameAccess().getFullStopKeyword_1_0());
            	    			
            	    this_ID_2=(Token)match(input,RULE_ID,FOLLOW_7); 

            	    				current.merge(this_ID_2);
            	    			

            	    				newLeafNode(this_ID_2, grammarAccess.getQualifiedNameAccess().getIDTerminalRuleCall_1_1());
            	    			

            	    }
            	    break;

            	default :
            	    break loop4;
                }
            } while (true);


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleQualifiedName"


    // $ANTLR start "entryRuleImport"
    // InternalOva.g:254:1: entryRuleImport returns [EObject current=null] : iv_ruleImport= ruleImport EOF ;
    public final EObject entryRuleImport() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleImport = null;


        try {
            // InternalOva.g:254:47: (iv_ruleImport= ruleImport EOF )
            // InternalOva.g:255:2: iv_ruleImport= ruleImport EOF
            {
             newCompositeNode(grammarAccess.getImportRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleImport=ruleImport();

            state._fsp--;

             current =iv_ruleImport; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleImport"


    // $ANTLR start "ruleImport"
    // InternalOva.g:261:1: ruleImport returns [EObject current=null] : (otherlv_0= 'import' ( (lv_importedNamespace_1_0= ruleQualifiedNameWithWildcard ) ) ) ;
    public final EObject ruleImport() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        AntlrDatatypeRuleToken lv_importedNamespace_1_0 = null;



        	enterRule();

        try {
            // InternalOva.g:267:2: ( (otherlv_0= 'import' ( (lv_importedNamespace_1_0= ruleQualifiedNameWithWildcard ) ) ) )
            // InternalOva.g:268:2: (otherlv_0= 'import' ( (lv_importedNamespace_1_0= ruleQualifiedNameWithWildcard ) ) )
            {
            // InternalOva.g:268:2: (otherlv_0= 'import' ( (lv_importedNamespace_1_0= ruleQualifiedNameWithWildcard ) ) )
            // InternalOva.g:269:3: otherlv_0= 'import' ( (lv_importedNamespace_1_0= ruleQualifiedNameWithWildcard ) )
            {
            otherlv_0=(Token)match(input,15,FOLLOW_4); 

            			newLeafNode(otherlv_0, grammarAccess.getImportAccess().getImportKeyword_0());
            		
            // InternalOva.g:273:3: ( (lv_importedNamespace_1_0= ruleQualifiedNameWithWildcard ) )
            // InternalOva.g:274:4: (lv_importedNamespace_1_0= ruleQualifiedNameWithWildcard )
            {
            // InternalOva.g:274:4: (lv_importedNamespace_1_0= ruleQualifiedNameWithWildcard )
            // InternalOva.g:275:5: lv_importedNamespace_1_0= ruleQualifiedNameWithWildcard
            {

            					newCompositeNode(grammarAccess.getImportAccess().getImportedNamespaceQualifiedNameWithWildcardParserRuleCall_1_0());
            				
            pushFollow(FOLLOW_2);
            lv_importedNamespace_1_0=ruleQualifiedNameWithWildcard();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getImportRule());
            					}
            					set(
            						current,
            						"importedNamespace",
            						lv_importedNamespace_1_0,
            						"newproject.dslovanes.Ova.QualifiedNameWithWildcard");
            					afterParserOrEnumRuleCall();
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleImport"


    // $ANTLR start "entryRuleQualifiedNameWithWildcard"
    // InternalOva.g:296:1: entryRuleQualifiedNameWithWildcard returns [String current=null] : iv_ruleQualifiedNameWithWildcard= ruleQualifiedNameWithWildcard EOF ;
    public final String entryRuleQualifiedNameWithWildcard() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleQualifiedNameWithWildcard = null;


        try {
            // InternalOva.g:296:65: (iv_ruleQualifiedNameWithWildcard= ruleQualifiedNameWithWildcard EOF )
            // InternalOva.g:297:2: iv_ruleQualifiedNameWithWildcard= ruleQualifiedNameWithWildcard EOF
            {
             newCompositeNode(grammarAccess.getQualifiedNameWithWildcardRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleQualifiedNameWithWildcard=ruleQualifiedNameWithWildcard();

            state._fsp--;

             current =iv_ruleQualifiedNameWithWildcard.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleQualifiedNameWithWildcard"


    // $ANTLR start "ruleQualifiedNameWithWildcard"
    // InternalOva.g:303:1: ruleQualifiedNameWithWildcard returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (this_QualifiedName_0= ruleQualifiedName (kw= '.*' )? ) ;
    public final AntlrDatatypeRuleToken ruleQualifiedNameWithWildcard() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;
        AntlrDatatypeRuleToken this_QualifiedName_0 = null;



        	enterRule();

        try {
            // InternalOva.g:309:2: ( (this_QualifiedName_0= ruleQualifiedName (kw= '.*' )? ) )
            // InternalOva.g:310:2: (this_QualifiedName_0= ruleQualifiedName (kw= '.*' )? )
            {
            // InternalOva.g:310:2: (this_QualifiedName_0= ruleQualifiedName (kw= '.*' )? )
            // InternalOva.g:311:3: this_QualifiedName_0= ruleQualifiedName (kw= '.*' )?
            {

            			newCompositeNode(grammarAccess.getQualifiedNameWithWildcardAccess().getQualifiedNameParserRuleCall_0());
            		
            pushFollow(FOLLOW_8);
            this_QualifiedName_0=ruleQualifiedName();

            state._fsp--;


            			current.merge(this_QualifiedName_0);
            		

            			afterParserOrEnumRuleCall();
            		
            // InternalOva.g:321:3: (kw= '.*' )?
            int alt5=2;
            int LA5_0 = input.LA(1);

            if ( (LA5_0==16) ) {
                alt5=1;
            }
            switch (alt5) {
                case 1 :
                    // InternalOva.g:322:4: kw= '.*'
                    {
                    kw=(Token)match(input,16,FOLLOW_2); 

                    				current.merge(kw);
                    				newLeafNode(kw, grammarAccess.getQualifiedNameWithWildcardAccess().getFullStopAsteriskKeyword_1());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleQualifiedNameWithWildcard"


    // $ANTLR start "entryRuleType"
    // InternalOva.g:332:1: entryRuleType returns [EObject current=null] : iv_ruleType= ruleType EOF ;
    public final EObject entryRuleType() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleType = null;


        try {
            // InternalOva.g:332:45: (iv_ruleType= ruleType EOF )
            // InternalOva.g:333:2: iv_ruleType= ruleType EOF
            {
             newCompositeNode(grammarAccess.getTypeRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleType=ruleType();

            state._fsp--;

             current =iv_ruleType; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleType"


    // $ANTLR start "ruleType"
    // InternalOva.g:339:1: ruleType returns [EObject current=null] : (this_DataType_0= ruleDataType | this_Enum_1= ruleEnum ) ;
    public final EObject ruleType() throws RecognitionException {
        EObject current = null;

        EObject this_DataType_0 = null;

        EObject this_Enum_1 = null;



        	enterRule();

        try {
            // InternalOva.g:345:2: ( (this_DataType_0= ruleDataType | this_Enum_1= ruleEnum ) )
            // InternalOva.g:346:2: (this_DataType_0= ruleDataType | this_Enum_1= ruleEnum )
            {
            // InternalOva.g:346:2: (this_DataType_0= ruleDataType | this_Enum_1= ruleEnum )
            int alt6=2;
            int LA6_0 = input.LA(1);

            if ( (LA6_0==17) ) {
                alt6=1;
            }
            else if ( (LA6_0==18) ) {
                alt6=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 6, 0, input);

                throw nvae;
            }
            switch (alt6) {
                case 1 :
                    // InternalOva.g:347:3: this_DataType_0= ruleDataType
                    {

                    			newCompositeNode(grammarAccess.getTypeAccess().getDataTypeParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_DataType_0=ruleDataType();

                    state._fsp--;


                    			current = this_DataType_0;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalOva.g:356:3: this_Enum_1= ruleEnum
                    {

                    			newCompositeNode(grammarAccess.getTypeAccess().getEnumParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_Enum_1=ruleEnum();

                    state._fsp--;


                    			current = this_Enum_1;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleType"


    // $ANTLR start "entryRuleDataType"
    // InternalOva.g:368:1: entryRuleDataType returns [EObject current=null] : iv_ruleDataType= ruleDataType EOF ;
    public final EObject entryRuleDataType() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleDataType = null;


        try {
            // InternalOva.g:368:49: (iv_ruleDataType= ruleDataType EOF )
            // InternalOva.g:369:2: iv_ruleDataType= ruleDataType EOF
            {
             newCompositeNode(grammarAccess.getDataTypeRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleDataType=ruleDataType();

            state._fsp--;

             current =iv_ruleDataType; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleDataType"


    // $ANTLR start "ruleDataType"
    // InternalOva.g:375:1: ruleDataType returns [EObject current=null] : (otherlv_0= 'datatype' ( (lv_name_1_0= RULE_ID ) ) ) ;
    public final EObject ruleDataType() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;


        	enterRule();

        try {
            // InternalOva.g:381:2: ( (otherlv_0= 'datatype' ( (lv_name_1_0= RULE_ID ) ) ) )
            // InternalOva.g:382:2: (otherlv_0= 'datatype' ( (lv_name_1_0= RULE_ID ) ) )
            {
            // InternalOva.g:382:2: (otherlv_0= 'datatype' ( (lv_name_1_0= RULE_ID ) ) )
            // InternalOva.g:383:3: otherlv_0= 'datatype' ( (lv_name_1_0= RULE_ID ) )
            {
            otherlv_0=(Token)match(input,17,FOLLOW_4); 

            			newLeafNode(otherlv_0, grammarAccess.getDataTypeAccess().getDatatypeKeyword_0());
            		
            // InternalOva.g:387:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalOva.g:388:4: (lv_name_1_0= RULE_ID )
            {
            // InternalOva.g:388:4: (lv_name_1_0= RULE_ID )
            // InternalOva.g:389:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_2); 

            					newLeafNode(lv_name_1_0, grammarAccess.getDataTypeAccess().getNameIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getDataTypeRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleDataType"


    // $ANTLR start "entryRuleEnum"
    // InternalOva.g:409:1: entryRuleEnum returns [EObject current=null] : iv_ruleEnum= ruleEnum EOF ;
    public final EObject entryRuleEnum() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleEnum = null;


        try {
            // InternalOva.g:409:45: (iv_ruleEnum= ruleEnum EOF )
            // InternalOva.g:410:2: iv_ruleEnum= ruleEnum EOF
            {
             newCompositeNode(grammarAccess.getEnumRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleEnum=ruleEnum();

            state._fsp--;

             current =iv_ruleEnum; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEnum"


    // $ANTLR start "ruleEnum"
    // InternalOva.g:416:1: ruleEnum returns [EObject current=null] : (otherlv_0= 'enum' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' ( (lv_literals_3_0= ruleLiteral ) ) (otherlv_4= '|' ( (lv_literals_5_0= ruleLiteral ) ) )* otherlv_6= '}' ) ;
    public final EObject ruleEnum() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        Token otherlv_6=null;
        EObject lv_literals_3_0 = null;

        EObject lv_literals_5_0 = null;



        	enterRule();

        try {
            // InternalOva.g:422:2: ( (otherlv_0= 'enum' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' ( (lv_literals_3_0= ruleLiteral ) ) (otherlv_4= '|' ( (lv_literals_5_0= ruleLiteral ) ) )* otherlv_6= '}' ) )
            // InternalOva.g:423:2: (otherlv_0= 'enum' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' ( (lv_literals_3_0= ruleLiteral ) ) (otherlv_4= '|' ( (lv_literals_5_0= ruleLiteral ) ) )* otherlv_6= '}' )
            {
            // InternalOva.g:423:2: (otherlv_0= 'enum' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' ( (lv_literals_3_0= ruleLiteral ) ) (otherlv_4= '|' ( (lv_literals_5_0= ruleLiteral ) ) )* otherlv_6= '}' )
            // InternalOva.g:424:3: otherlv_0= 'enum' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' ( (lv_literals_3_0= ruleLiteral ) ) (otherlv_4= '|' ( (lv_literals_5_0= ruleLiteral ) ) )* otherlv_6= '}'
            {
            otherlv_0=(Token)match(input,18,FOLLOW_4); 

            			newLeafNode(otherlv_0, grammarAccess.getEnumAccess().getEnumKeyword_0());
            		
            // InternalOva.g:428:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalOva.g:429:4: (lv_name_1_0= RULE_ID )
            {
            // InternalOva.g:429:4: (lv_name_1_0= RULE_ID )
            // InternalOva.g:430:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_5); 

            					newLeafNode(lv_name_1_0, grammarAccess.getEnumAccess().getNameIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getEnumRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_2=(Token)match(input,12,FOLLOW_4); 

            			newLeafNode(otherlv_2, grammarAccess.getEnumAccess().getLeftCurlyBracketKeyword_2());
            		
            // InternalOva.g:450:3: ( (lv_literals_3_0= ruleLiteral ) )
            // InternalOva.g:451:4: (lv_literals_3_0= ruleLiteral )
            {
            // InternalOva.g:451:4: (lv_literals_3_0= ruleLiteral )
            // InternalOva.g:452:5: lv_literals_3_0= ruleLiteral
            {

            					newCompositeNode(grammarAccess.getEnumAccess().getLiteralsLiteralParserRuleCall_3_0());
            				
            pushFollow(FOLLOW_9);
            lv_literals_3_0=ruleLiteral();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getEnumRule());
            					}
            					add(
            						current,
            						"literals",
            						lv_literals_3_0,
            						"newproject.dslovanes.Ova.Literal");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalOva.g:469:3: (otherlv_4= '|' ( (lv_literals_5_0= ruleLiteral ) ) )*
            loop7:
            do {
                int alt7=2;
                int LA7_0 = input.LA(1);

                if ( (LA7_0==19) ) {
                    alt7=1;
                }


                switch (alt7) {
            	case 1 :
            	    // InternalOva.g:470:4: otherlv_4= '|' ( (lv_literals_5_0= ruleLiteral ) )
            	    {
            	    otherlv_4=(Token)match(input,19,FOLLOW_4); 

            	    				newLeafNode(otherlv_4, grammarAccess.getEnumAccess().getVerticalLineKeyword_4_0());
            	    			
            	    // InternalOva.g:474:4: ( (lv_literals_5_0= ruleLiteral ) )
            	    // InternalOva.g:475:5: (lv_literals_5_0= ruleLiteral )
            	    {
            	    // InternalOva.g:475:5: (lv_literals_5_0= ruleLiteral )
            	    // InternalOva.g:476:6: lv_literals_5_0= ruleLiteral
            	    {

            	    						newCompositeNode(grammarAccess.getEnumAccess().getLiteralsLiteralParserRuleCall_4_1_0());
            	    					
            	    pushFollow(FOLLOW_9);
            	    lv_literals_5_0=ruleLiteral();

            	    state._fsp--;


            	    						if (current==null) {
            	    							current = createModelElementForParent(grammarAccess.getEnumRule());
            	    						}
            	    						add(
            	    							current,
            	    							"literals",
            	    							lv_literals_5_0,
            	    							"newproject.dslovanes.Ova.Literal");
            	    						afterParserOrEnumRuleCall();
            	    					

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    break loop7;
                }
            } while (true);

            otherlv_6=(Token)match(input,13,FOLLOW_2); 

            			newLeafNode(otherlv_6, grammarAccess.getEnumAccess().getRightCurlyBracketKeyword_5());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEnum"


    // $ANTLR start "entryRuleLiteral"
    // InternalOva.g:502:1: entryRuleLiteral returns [EObject current=null] : iv_ruleLiteral= ruleLiteral EOF ;
    public final EObject entryRuleLiteral() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleLiteral = null;


        try {
            // InternalOva.g:502:48: (iv_ruleLiteral= ruleLiteral EOF )
            // InternalOva.g:503:2: iv_ruleLiteral= ruleLiteral EOF
            {
             newCompositeNode(grammarAccess.getLiteralRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleLiteral=ruleLiteral();

            state._fsp--;

             current =iv_ruleLiteral; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleLiteral"


    // $ANTLR start "ruleLiteral"
    // InternalOva.g:509:1: ruleLiteral returns [EObject current=null] : ( ( (lv_name_0_0= RULE_ID ) ) otherlv_1= '=' ( (lv_value_2_0= RULE_STRING ) ) ) ;
    public final EObject ruleLiteral() throws RecognitionException {
        EObject current = null;

        Token lv_name_0_0=null;
        Token otherlv_1=null;
        Token lv_value_2_0=null;


        	enterRule();

        try {
            // InternalOva.g:515:2: ( ( ( (lv_name_0_0= RULE_ID ) ) otherlv_1= '=' ( (lv_value_2_0= RULE_STRING ) ) ) )
            // InternalOva.g:516:2: ( ( (lv_name_0_0= RULE_ID ) ) otherlv_1= '=' ( (lv_value_2_0= RULE_STRING ) ) )
            {
            // InternalOva.g:516:2: ( ( (lv_name_0_0= RULE_ID ) ) otherlv_1= '=' ( (lv_value_2_0= RULE_STRING ) ) )
            // InternalOva.g:517:3: ( (lv_name_0_0= RULE_ID ) ) otherlv_1= '=' ( (lv_value_2_0= RULE_STRING ) )
            {
            // InternalOva.g:517:3: ( (lv_name_0_0= RULE_ID ) )
            // InternalOva.g:518:4: (lv_name_0_0= RULE_ID )
            {
            // InternalOva.g:518:4: (lv_name_0_0= RULE_ID )
            // InternalOva.g:519:5: lv_name_0_0= RULE_ID
            {
            lv_name_0_0=(Token)match(input,RULE_ID,FOLLOW_10); 

            					newLeafNode(lv_name_0_0, grammarAccess.getLiteralAccess().getNameIDTerminalRuleCall_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getLiteralRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_0_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_1=(Token)match(input,20,FOLLOW_11); 

            			newLeafNode(otherlv_1, grammarAccess.getLiteralAccess().getEqualsSignKeyword_1());
            		
            // InternalOva.g:539:3: ( (lv_value_2_0= RULE_STRING ) )
            // InternalOva.g:540:4: (lv_value_2_0= RULE_STRING )
            {
            // InternalOva.g:540:4: (lv_value_2_0= RULE_STRING )
            // InternalOva.g:541:5: lv_value_2_0= RULE_STRING
            {
            lv_value_2_0=(Token)match(input,RULE_STRING,FOLLOW_2); 

            					newLeafNode(lv_value_2_0, grammarAccess.getLiteralAccess().getValueSTRINGTerminalRuleCall_2_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getLiteralRule());
            					}
            					setWithLastConsumed(
            						current,
            						"value",
            						lv_value_2_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleLiteral"


    // $ANTLR start "entryRuleProperty"
    // InternalOva.g:561:1: entryRuleProperty returns [EObject current=null] : iv_ruleProperty= ruleProperty EOF ;
    public final EObject entryRuleProperty() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleProperty = null;


        try {
            // InternalOva.g:561:49: (iv_ruleProperty= ruleProperty EOF )
            // InternalOva.g:562:2: iv_ruleProperty= ruleProperty EOF
            {
             newCompositeNode(grammarAccess.getPropertyRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleProperty=ruleProperty();

            state._fsp--;

             current =iv_ruleProperty; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleProperty"


    // $ANTLR start "ruleProperty"
    // InternalOva.g:568:1: ruleProperty returns [EObject current=null] : (this_DataTypeProperty_0= ruleDataTypeProperty | this_EnumProperty_1= ruleEnumProperty ) ;
    public final EObject ruleProperty() throws RecognitionException {
        EObject current = null;

        EObject this_DataTypeProperty_0 = null;

        EObject this_EnumProperty_1 = null;



        	enterRule();

        try {
            // InternalOva.g:574:2: ( (this_DataTypeProperty_0= ruleDataTypeProperty | this_EnumProperty_1= ruleEnumProperty ) )
            // InternalOva.g:575:2: (this_DataTypeProperty_0= ruleDataTypeProperty | this_EnumProperty_1= ruleEnumProperty )
            {
            // InternalOva.g:575:2: (this_DataTypeProperty_0= ruleDataTypeProperty | this_EnumProperty_1= ruleEnumProperty )
            int alt8=2;
            alt8 = dfa8.predict(input);
            switch (alt8) {
                case 1 :
                    // InternalOva.g:576:3: this_DataTypeProperty_0= ruleDataTypeProperty
                    {

                    			newCompositeNode(grammarAccess.getPropertyAccess().getDataTypePropertyParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_DataTypeProperty_0=ruleDataTypeProperty();

                    state._fsp--;


                    			current = this_DataTypeProperty_0;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalOva.g:585:3: this_EnumProperty_1= ruleEnumProperty
                    {

                    			newCompositeNode(grammarAccess.getPropertyAccess().getEnumPropertyParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_EnumProperty_1=ruleEnumProperty();

                    state._fsp--;


                    			current = this_EnumProperty_1;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleProperty"


    // $ANTLR start "entryRuleDataTypeProperty"
    // InternalOva.g:597:1: entryRuleDataTypeProperty returns [EObject current=null] : iv_ruleDataTypeProperty= ruleDataTypeProperty EOF ;
    public final EObject entryRuleDataTypeProperty() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleDataTypeProperty = null;


        try {
            // InternalOva.g:597:57: (iv_ruleDataTypeProperty= ruleDataTypeProperty EOF )
            // InternalOva.g:598:2: iv_ruleDataTypeProperty= ruleDataTypeProperty EOF
            {
             newCompositeNode(grammarAccess.getDataTypePropertyRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleDataTypeProperty=ruleDataTypeProperty();

            state._fsp--;

             current =iv_ruleDataTypeProperty; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleDataTypeProperty"


    // $ANTLR start "ruleDataTypeProperty"
    // InternalOva.g:604:1: ruleDataTypeProperty returns [EObject current=null] : ( ( ( ruleQualifiedName ) ) ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '=' ( (lv_value_3_0= RULE_STRING ) ) (otherlv_4= 'requires' ( ( ruleQualifiedName ) ) )? ) ;
    public final EObject ruleDataTypeProperty() throws RecognitionException {
        EObject current = null;

        Token lv_name_1_0=null;
        Token otherlv_2=null;
        Token lv_value_3_0=null;
        Token otherlv_4=null;


        	enterRule();

        try {
            // InternalOva.g:610:2: ( ( ( ( ruleQualifiedName ) ) ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '=' ( (lv_value_3_0= RULE_STRING ) ) (otherlv_4= 'requires' ( ( ruleQualifiedName ) ) )? ) )
            // InternalOva.g:611:2: ( ( ( ruleQualifiedName ) ) ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '=' ( (lv_value_3_0= RULE_STRING ) ) (otherlv_4= 'requires' ( ( ruleQualifiedName ) ) )? )
            {
            // InternalOva.g:611:2: ( ( ( ruleQualifiedName ) ) ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '=' ( (lv_value_3_0= RULE_STRING ) ) (otherlv_4= 'requires' ( ( ruleQualifiedName ) ) )? )
            // InternalOva.g:612:3: ( ( ruleQualifiedName ) ) ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '=' ( (lv_value_3_0= RULE_STRING ) ) (otherlv_4= 'requires' ( ( ruleQualifiedName ) ) )?
            {
            // InternalOva.g:612:3: ( ( ruleQualifiedName ) )
            // InternalOva.g:613:4: ( ruleQualifiedName )
            {
            // InternalOva.g:613:4: ( ruleQualifiedName )
            // InternalOva.g:614:5: ruleQualifiedName
            {

            					if (current==null) {
            						current = createModelElement(grammarAccess.getDataTypePropertyRule());
            					}
            				

            					newCompositeNode(grammarAccess.getDataTypePropertyAccess().getTypeDataTypeCrossReference_0_0());
            				
            pushFollow(FOLLOW_4);
            ruleQualifiedName();

            state._fsp--;


            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalOva.g:628:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalOva.g:629:4: (lv_name_1_0= RULE_ID )
            {
            // InternalOva.g:629:4: (lv_name_1_0= RULE_ID )
            // InternalOva.g:630:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_10); 

            					newLeafNode(lv_name_1_0, grammarAccess.getDataTypePropertyAccess().getNameIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getDataTypePropertyRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_2=(Token)match(input,20,FOLLOW_11); 

            			newLeafNode(otherlv_2, grammarAccess.getDataTypePropertyAccess().getEqualsSignKeyword_2());
            		
            // InternalOva.g:650:3: ( (lv_value_3_0= RULE_STRING ) )
            // InternalOva.g:651:4: (lv_value_3_0= RULE_STRING )
            {
            // InternalOva.g:651:4: (lv_value_3_0= RULE_STRING )
            // InternalOva.g:652:5: lv_value_3_0= RULE_STRING
            {
            lv_value_3_0=(Token)match(input,RULE_STRING,FOLLOW_12); 

            					newLeafNode(lv_value_3_0, grammarAccess.getDataTypePropertyAccess().getValueSTRINGTerminalRuleCall_3_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getDataTypePropertyRule());
            					}
            					setWithLastConsumed(
            						current,
            						"value",
            						lv_value_3_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            // InternalOva.g:668:3: (otherlv_4= 'requires' ( ( ruleQualifiedName ) ) )?
            int alt9=2;
            int LA9_0 = input.LA(1);

            if ( (LA9_0==21) ) {
                alt9=1;
            }
            switch (alt9) {
                case 1 :
                    // InternalOva.g:669:4: otherlv_4= 'requires' ( ( ruleQualifiedName ) )
                    {
                    otherlv_4=(Token)match(input,21,FOLLOW_4); 

                    				newLeafNode(otherlv_4, grammarAccess.getDataTypePropertyAccess().getRequiresKeyword_4_0());
                    			
                    // InternalOva.g:673:4: ( ( ruleQualifiedName ) )
                    // InternalOva.g:674:5: ( ruleQualifiedName )
                    {
                    // InternalOva.g:674:5: ( ruleQualifiedName )
                    // InternalOva.g:675:6: ruleQualifiedName
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getDataTypePropertyRule());
                    						}
                    					

                    						newCompositeNode(grammarAccess.getDataTypePropertyAccess().getRequiredEnumLiteralLiteralCrossReference_4_1_0());
                    					
                    pushFollow(FOLLOW_2);
                    ruleQualifiedName();

                    state._fsp--;


                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleDataTypeProperty"


    // $ANTLR start "entryRuleEnumProperty"
    // InternalOva.g:694:1: entryRuleEnumProperty returns [EObject current=null] : iv_ruleEnumProperty= ruleEnumProperty EOF ;
    public final EObject entryRuleEnumProperty() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleEnumProperty = null;


        try {
            // InternalOva.g:694:53: (iv_ruleEnumProperty= ruleEnumProperty EOF )
            // InternalOva.g:695:2: iv_ruleEnumProperty= ruleEnumProperty EOF
            {
             newCompositeNode(grammarAccess.getEnumPropertyRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleEnumProperty=ruleEnumProperty();

            state._fsp--;

             current =iv_ruleEnumProperty; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEnumProperty"


    // $ANTLR start "ruleEnumProperty"
    // InternalOva.g:701:1: ruleEnumProperty returns [EObject current=null] : ( ( ( ruleQualifiedName ) ) ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '=' ( ( ruleQualifiedName ) ) (otherlv_4= 'requires' ( ( ruleQualifiedName ) ) )? ) ;
    public final EObject ruleEnumProperty() throws RecognitionException {
        EObject current = null;

        Token lv_name_1_0=null;
        Token otherlv_2=null;
        Token otherlv_4=null;


        	enterRule();

        try {
            // InternalOva.g:707:2: ( ( ( ( ruleQualifiedName ) ) ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '=' ( ( ruleQualifiedName ) ) (otherlv_4= 'requires' ( ( ruleQualifiedName ) ) )? ) )
            // InternalOva.g:708:2: ( ( ( ruleQualifiedName ) ) ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '=' ( ( ruleQualifiedName ) ) (otherlv_4= 'requires' ( ( ruleQualifiedName ) ) )? )
            {
            // InternalOva.g:708:2: ( ( ( ruleQualifiedName ) ) ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '=' ( ( ruleQualifiedName ) ) (otherlv_4= 'requires' ( ( ruleQualifiedName ) ) )? )
            // InternalOva.g:709:3: ( ( ruleQualifiedName ) ) ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '=' ( ( ruleQualifiedName ) ) (otherlv_4= 'requires' ( ( ruleQualifiedName ) ) )?
            {
            // InternalOva.g:709:3: ( ( ruleQualifiedName ) )
            // InternalOva.g:710:4: ( ruleQualifiedName )
            {
            // InternalOva.g:710:4: ( ruleQualifiedName )
            // InternalOva.g:711:5: ruleQualifiedName
            {

            					if (current==null) {
            						current = createModelElement(grammarAccess.getEnumPropertyRule());
            					}
            				

            					newCompositeNode(grammarAccess.getEnumPropertyAccess().getTypeEnumCrossReference_0_0());
            				
            pushFollow(FOLLOW_4);
            ruleQualifiedName();

            state._fsp--;


            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalOva.g:725:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalOva.g:726:4: (lv_name_1_0= RULE_ID )
            {
            // InternalOva.g:726:4: (lv_name_1_0= RULE_ID )
            // InternalOva.g:727:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_10); 

            					newLeafNode(lv_name_1_0, grammarAccess.getEnumPropertyAccess().getNameIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getEnumPropertyRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_2=(Token)match(input,20,FOLLOW_4); 

            			newLeafNode(otherlv_2, grammarAccess.getEnumPropertyAccess().getEqualsSignKeyword_2());
            		
            // InternalOva.g:747:3: ( ( ruleQualifiedName ) )
            // InternalOva.g:748:4: ( ruleQualifiedName )
            {
            // InternalOva.g:748:4: ( ruleQualifiedName )
            // InternalOva.g:749:5: ruleQualifiedName
            {

            					if (current==null) {
            						current = createModelElement(grammarAccess.getEnumPropertyRule());
            					}
            				

            					newCompositeNode(grammarAccess.getEnumPropertyAccess().getValueLiteralCrossReference_3_0());
            				
            pushFollow(FOLLOW_12);
            ruleQualifiedName();

            state._fsp--;


            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalOva.g:763:3: (otherlv_4= 'requires' ( ( ruleQualifiedName ) ) )?
            int alt10=2;
            int LA10_0 = input.LA(1);

            if ( (LA10_0==21) ) {
                alt10=1;
            }
            switch (alt10) {
                case 1 :
                    // InternalOva.g:764:4: otherlv_4= 'requires' ( ( ruleQualifiedName ) )
                    {
                    otherlv_4=(Token)match(input,21,FOLLOW_4); 

                    				newLeafNode(otherlv_4, grammarAccess.getEnumPropertyAccess().getRequiresKeyword_4_0());
                    			
                    // InternalOva.g:768:4: ( ( ruleQualifiedName ) )
                    // InternalOva.g:769:5: ( ruleQualifiedName )
                    {
                    // InternalOva.g:769:5: ( ruleQualifiedName )
                    // InternalOva.g:770:6: ruleQualifiedName
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getEnumPropertyRule());
                    						}
                    					

                    						newCompositeNode(grammarAccess.getEnumPropertyAccess().getRequiredEnumLiteralLiteralCrossReference_4_1_0());
                    					
                    pushFollow(FOLLOW_2);
                    ruleQualifiedName();

                    state._fsp--;


                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEnumProperty"


    // $ANTLR start "entryRuleTestCase"
    // InternalOva.g:789:1: entryRuleTestCase returns [EObject current=null] : iv_ruleTestCase= ruleTestCase EOF ;
    public final EObject entryRuleTestCase() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleTestCase = null;


        try {
            // InternalOva.g:789:49: (iv_ruleTestCase= ruleTestCase EOF )
            // InternalOva.g:790:2: iv_ruleTestCase= ruleTestCase EOF
            {
             newCompositeNode(grammarAccess.getTestCaseRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleTestCase=ruleTestCase();

            state._fsp--;

             current =iv_ruleTestCase; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleTestCase"


    // $ANTLR start "ruleTestCase"
    // InternalOva.g:796:1: ruleTestCase returns [EObject current=null] : (otherlv_0= 'TestCase' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= 'on' ( ( ruleQualifiedName ) ) (otherlv_4= ',' ( ( ruleQualifiedName ) ) )* otherlv_6= '{' ( (lv_input_7_0= ruleInput ) ) ( (lv_expectation_8_0= ruleExpectation ) ) otherlv_9= '}' ) ;
    public final EObject ruleTestCase() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        Token otherlv_6=null;
        Token otherlv_9=null;
        EObject lv_input_7_0 = null;

        EObject lv_expectation_8_0 = null;



        	enterRule();

        try {
            // InternalOva.g:802:2: ( (otherlv_0= 'TestCase' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= 'on' ( ( ruleQualifiedName ) ) (otherlv_4= ',' ( ( ruleQualifiedName ) ) )* otherlv_6= '{' ( (lv_input_7_0= ruleInput ) ) ( (lv_expectation_8_0= ruleExpectation ) ) otherlv_9= '}' ) )
            // InternalOva.g:803:2: (otherlv_0= 'TestCase' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= 'on' ( ( ruleQualifiedName ) ) (otherlv_4= ',' ( ( ruleQualifiedName ) ) )* otherlv_6= '{' ( (lv_input_7_0= ruleInput ) ) ( (lv_expectation_8_0= ruleExpectation ) ) otherlv_9= '}' )
            {
            // InternalOva.g:803:2: (otherlv_0= 'TestCase' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= 'on' ( ( ruleQualifiedName ) ) (otherlv_4= ',' ( ( ruleQualifiedName ) ) )* otherlv_6= '{' ( (lv_input_7_0= ruleInput ) ) ( (lv_expectation_8_0= ruleExpectation ) ) otherlv_9= '}' )
            // InternalOva.g:804:3: otherlv_0= 'TestCase' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= 'on' ( ( ruleQualifiedName ) ) (otherlv_4= ',' ( ( ruleQualifiedName ) ) )* otherlv_6= '{' ( (lv_input_7_0= ruleInput ) ) ( (lv_expectation_8_0= ruleExpectation ) ) otherlv_9= '}'
            {
            otherlv_0=(Token)match(input,22,FOLLOW_4); 

            			newLeafNode(otherlv_0, grammarAccess.getTestCaseAccess().getTestCaseKeyword_0());
            		
            // InternalOva.g:808:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalOva.g:809:4: (lv_name_1_0= RULE_ID )
            {
            // InternalOva.g:809:4: (lv_name_1_0= RULE_ID )
            // InternalOva.g:810:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_13); 

            					newLeafNode(lv_name_1_0, grammarAccess.getTestCaseAccess().getNameIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getTestCaseRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_2=(Token)match(input,23,FOLLOW_4); 

            			newLeafNode(otherlv_2, grammarAccess.getTestCaseAccess().getOnKeyword_2());
            		
            // InternalOva.g:830:3: ( ( ruleQualifiedName ) )
            // InternalOva.g:831:4: ( ruleQualifiedName )
            {
            // InternalOva.g:831:4: ( ruleQualifiedName )
            // InternalOva.g:832:5: ruleQualifiedName
            {

            					if (current==null) {
            						current = createModelElement(grammarAccess.getTestCaseRule());
            					}
            				

            					newCompositeNode(grammarAccess.getTestCaseAccess().getServersLiteralCrossReference_3_0());
            				
            pushFollow(FOLLOW_14);
            ruleQualifiedName();

            state._fsp--;


            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalOva.g:846:3: (otherlv_4= ',' ( ( ruleQualifiedName ) ) )*
            loop11:
            do {
                int alt11=2;
                int LA11_0 = input.LA(1);

                if ( (LA11_0==24) ) {
                    alt11=1;
                }


                switch (alt11) {
            	case 1 :
            	    // InternalOva.g:847:4: otherlv_4= ',' ( ( ruleQualifiedName ) )
            	    {
            	    otherlv_4=(Token)match(input,24,FOLLOW_4); 

            	    				newLeafNode(otherlv_4, grammarAccess.getTestCaseAccess().getCommaKeyword_4_0());
            	    			
            	    // InternalOva.g:851:4: ( ( ruleQualifiedName ) )
            	    // InternalOva.g:852:5: ( ruleQualifiedName )
            	    {
            	    // InternalOva.g:852:5: ( ruleQualifiedName )
            	    // InternalOva.g:853:6: ruleQualifiedName
            	    {

            	    						if (current==null) {
            	    							current = createModelElement(grammarAccess.getTestCaseRule());
            	    						}
            	    					

            	    						newCompositeNode(grammarAccess.getTestCaseAccess().getServersLiteralCrossReference_4_1_0());
            	    					
            	    pushFollow(FOLLOW_14);
            	    ruleQualifiedName();

            	    state._fsp--;


            	    						afterParserOrEnumRuleCall();
            	    					

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    break loop11;
                }
            } while (true);

            otherlv_6=(Token)match(input,12,FOLLOW_15); 

            			newLeafNode(otherlv_6, grammarAccess.getTestCaseAccess().getLeftCurlyBracketKeyword_5());
            		
            // InternalOva.g:872:3: ( (lv_input_7_0= ruleInput ) )
            // InternalOva.g:873:4: (lv_input_7_0= ruleInput )
            {
            // InternalOva.g:873:4: (lv_input_7_0= ruleInput )
            // InternalOva.g:874:5: lv_input_7_0= ruleInput
            {

            					newCompositeNode(grammarAccess.getTestCaseAccess().getInputInputParserRuleCall_6_0());
            				
            pushFollow(FOLLOW_16);
            lv_input_7_0=ruleInput();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getTestCaseRule());
            					}
            					set(
            						current,
            						"input",
            						lv_input_7_0,
            						"newproject.dslovanes.Ova.Input");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalOva.g:891:3: ( (lv_expectation_8_0= ruleExpectation ) )
            // InternalOva.g:892:4: (lv_expectation_8_0= ruleExpectation )
            {
            // InternalOva.g:892:4: (lv_expectation_8_0= ruleExpectation )
            // InternalOva.g:893:5: lv_expectation_8_0= ruleExpectation
            {

            					newCompositeNode(grammarAccess.getTestCaseAccess().getExpectationExpectationParserRuleCall_7_0());
            				
            pushFollow(FOLLOW_17);
            lv_expectation_8_0=ruleExpectation();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getTestCaseRule());
            					}
            					set(
            						current,
            						"expectation",
            						lv_expectation_8_0,
            						"newproject.dslovanes.Ova.Expectation");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_9=(Token)match(input,13,FOLLOW_2); 

            			newLeafNode(otherlv_9, grammarAccess.getTestCaseAccess().getRightCurlyBracketKeyword_8());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTestCase"


    // $ANTLR start "entryRuleInput"
    // InternalOva.g:918:1: entryRuleInput returns [EObject current=null] : iv_ruleInput= ruleInput EOF ;
    public final EObject entryRuleInput() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleInput = null;


        try {
            // InternalOva.g:918:46: (iv_ruleInput= ruleInput EOF )
            // InternalOva.g:919:2: iv_ruleInput= ruleInput EOF
            {
             newCompositeNode(grammarAccess.getInputRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleInput=ruleInput();

            state._fsp--;

             current =iv_ruleInput; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleInput"


    // $ANTLR start "ruleInput"
    // InternalOva.g:925:1: ruleInput returns [EObject current=null] : (otherlv_0= 'tests' ( (lv_name_1_0= 'input' ) ) otherlv_2= '{' (otherlv_3= 'val' ( (lv_properties_4_0= ruleProperty ) ) )* otherlv_5= '}' ) ;
    public final EObject ruleInput() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        EObject lv_properties_4_0 = null;



        	enterRule();

        try {
            // InternalOva.g:931:2: ( (otherlv_0= 'tests' ( (lv_name_1_0= 'input' ) ) otherlv_2= '{' (otherlv_3= 'val' ( (lv_properties_4_0= ruleProperty ) ) )* otherlv_5= '}' ) )
            // InternalOva.g:932:2: (otherlv_0= 'tests' ( (lv_name_1_0= 'input' ) ) otherlv_2= '{' (otherlv_3= 'val' ( (lv_properties_4_0= ruleProperty ) ) )* otherlv_5= '}' )
            {
            // InternalOva.g:932:2: (otherlv_0= 'tests' ( (lv_name_1_0= 'input' ) ) otherlv_2= '{' (otherlv_3= 'val' ( (lv_properties_4_0= ruleProperty ) ) )* otherlv_5= '}' )
            // InternalOva.g:933:3: otherlv_0= 'tests' ( (lv_name_1_0= 'input' ) ) otherlv_2= '{' (otherlv_3= 'val' ( (lv_properties_4_0= ruleProperty ) ) )* otherlv_5= '}'
            {
            otherlv_0=(Token)match(input,25,FOLLOW_18); 

            			newLeafNode(otherlv_0, grammarAccess.getInputAccess().getTestsKeyword_0());
            		
            // InternalOva.g:937:3: ( (lv_name_1_0= 'input' ) )
            // InternalOva.g:938:4: (lv_name_1_0= 'input' )
            {
            // InternalOva.g:938:4: (lv_name_1_0= 'input' )
            // InternalOva.g:939:5: lv_name_1_0= 'input'
            {
            lv_name_1_0=(Token)match(input,26,FOLLOW_5); 

            					newLeafNode(lv_name_1_0, grammarAccess.getInputAccess().getNameInputKeyword_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getInputRule());
            					}
            					setWithLastConsumed(current, "name", lv_name_1_0, "input");
            				

            }


            }

            otherlv_2=(Token)match(input,12,FOLLOW_19); 

            			newLeafNode(otherlv_2, grammarAccess.getInputAccess().getLeftCurlyBracketKeyword_2());
            		
            // InternalOva.g:955:3: (otherlv_3= 'val' ( (lv_properties_4_0= ruleProperty ) ) )*
            loop12:
            do {
                int alt12=2;
                int LA12_0 = input.LA(1);

                if ( (LA12_0==27) ) {
                    alt12=1;
                }


                switch (alt12) {
            	case 1 :
            	    // InternalOva.g:956:4: otherlv_3= 'val' ( (lv_properties_4_0= ruleProperty ) )
            	    {
            	    otherlv_3=(Token)match(input,27,FOLLOW_4); 

            	    				newLeafNode(otherlv_3, grammarAccess.getInputAccess().getValKeyword_3_0());
            	    			
            	    // InternalOva.g:960:4: ( (lv_properties_4_0= ruleProperty ) )
            	    // InternalOva.g:961:5: (lv_properties_4_0= ruleProperty )
            	    {
            	    // InternalOva.g:961:5: (lv_properties_4_0= ruleProperty )
            	    // InternalOva.g:962:6: lv_properties_4_0= ruleProperty
            	    {

            	    						newCompositeNode(grammarAccess.getInputAccess().getPropertiesPropertyParserRuleCall_3_1_0());
            	    					
            	    pushFollow(FOLLOW_19);
            	    lv_properties_4_0=ruleProperty();

            	    state._fsp--;


            	    						if (current==null) {
            	    							current = createModelElementForParent(grammarAccess.getInputRule());
            	    						}
            	    						add(
            	    							current,
            	    							"properties",
            	    							lv_properties_4_0,
            	    							"newproject.dslovanes.Ova.Property");
            	    						afterParserOrEnumRuleCall();
            	    					

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    break loop12;
                }
            } while (true);

            otherlv_5=(Token)match(input,13,FOLLOW_2); 

            			newLeafNode(otherlv_5, grammarAccess.getInputAccess().getRightCurlyBracketKeyword_4());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleInput"


    // $ANTLR start "entryRuleExpectation"
    // InternalOva.g:988:1: entryRuleExpectation returns [EObject current=null] : iv_ruleExpectation= ruleExpectation EOF ;
    public final EObject entryRuleExpectation() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleExpectation = null;


        try {
            // InternalOva.g:988:52: (iv_ruleExpectation= ruleExpectation EOF )
            // InternalOva.g:989:2: iv_ruleExpectation= ruleExpectation EOF
            {
             newCompositeNode(grammarAccess.getExpectationRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleExpectation=ruleExpectation();

            state._fsp--;

             current =iv_ruleExpectation; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleExpectation"


    // $ANTLR start "ruleExpectation"
    // InternalOva.g:995:1: ruleExpectation returns [EObject current=null] : (otherlv_0= 'verifies' ( (lv_name_1_0= 'output' ) ) otherlv_2= '{' (otherlv_3= 'val' ( (lv_properties_4_0= ruleProperty ) ) )* otherlv_5= '}' ) ;
    public final EObject ruleExpectation() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        EObject lv_properties_4_0 = null;



        	enterRule();

        try {
            // InternalOva.g:1001:2: ( (otherlv_0= 'verifies' ( (lv_name_1_0= 'output' ) ) otherlv_2= '{' (otherlv_3= 'val' ( (lv_properties_4_0= ruleProperty ) ) )* otherlv_5= '}' ) )
            // InternalOva.g:1002:2: (otherlv_0= 'verifies' ( (lv_name_1_0= 'output' ) ) otherlv_2= '{' (otherlv_3= 'val' ( (lv_properties_4_0= ruleProperty ) ) )* otherlv_5= '}' )
            {
            // InternalOva.g:1002:2: (otherlv_0= 'verifies' ( (lv_name_1_0= 'output' ) ) otherlv_2= '{' (otherlv_3= 'val' ( (lv_properties_4_0= ruleProperty ) ) )* otherlv_5= '}' )
            // InternalOva.g:1003:3: otherlv_0= 'verifies' ( (lv_name_1_0= 'output' ) ) otherlv_2= '{' (otherlv_3= 'val' ( (lv_properties_4_0= ruleProperty ) ) )* otherlv_5= '}'
            {
            otherlv_0=(Token)match(input,28,FOLLOW_20); 

            			newLeafNode(otherlv_0, grammarAccess.getExpectationAccess().getVerifiesKeyword_0());
            		
            // InternalOva.g:1007:3: ( (lv_name_1_0= 'output' ) )
            // InternalOva.g:1008:4: (lv_name_1_0= 'output' )
            {
            // InternalOva.g:1008:4: (lv_name_1_0= 'output' )
            // InternalOva.g:1009:5: lv_name_1_0= 'output'
            {
            lv_name_1_0=(Token)match(input,29,FOLLOW_5); 

            					newLeafNode(lv_name_1_0, grammarAccess.getExpectationAccess().getNameOutputKeyword_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getExpectationRule());
            					}
            					setWithLastConsumed(current, "name", lv_name_1_0, "output");
            				

            }


            }

            otherlv_2=(Token)match(input,12,FOLLOW_19); 

            			newLeafNode(otherlv_2, grammarAccess.getExpectationAccess().getLeftCurlyBracketKeyword_2());
            		
            // InternalOva.g:1025:3: (otherlv_3= 'val' ( (lv_properties_4_0= ruleProperty ) ) )*
            loop13:
            do {
                int alt13=2;
                int LA13_0 = input.LA(1);

                if ( (LA13_0==27) ) {
                    alt13=1;
                }


                switch (alt13) {
            	case 1 :
            	    // InternalOva.g:1026:4: otherlv_3= 'val' ( (lv_properties_4_0= ruleProperty ) )
            	    {
            	    otherlv_3=(Token)match(input,27,FOLLOW_4); 

            	    				newLeafNode(otherlv_3, grammarAccess.getExpectationAccess().getValKeyword_3_0());
            	    			
            	    // InternalOva.g:1030:4: ( (lv_properties_4_0= ruleProperty ) )
            	    // InternalOva.g:1031:5: (lv_properties_4_0= ruleProperty )
            	    {
            	    // InternalOva.g:1031:5: (lv_properties_4_0= ruleProperty )
            	    // InternalOva.g:1032:6: lv_properties_4_0= ruleProperty
            	    {

            	    						newCompositeNode(grammarAccess.getExpectationAccess().getPropertiesPropertyParserRuleCall_3_1_0());
            	    					
            	    pushFollow(FOLLOW_19);
            	    lv_properties_4_0=ruleProperty();

            	    state._fsp--;


            	    						if (current==null) {
            	    							current = createModelElementForParent(grammarAccess.getExpectationRule());
            	    						}
            	    						add(
            	    							current,
            	    							"properties",
            	    							lv_properties_4_0,
            	    							"newproject.dslovanes.Ova.Property");
            	    						afterParserOrEnumRuleCall();
            	    					

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    break loop13;
                }
            } while (true);

            otherlv_5=(Token)match(input,13,FOLLOW_2); 

            			newLeafNode(otherlv_5, grammarAccess.getExpectationAccess().getRightCurlyBracketKeyword_4());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleExpectation"

    // Delegated rules


    protected DFA8 dfa8 = new DFA8(this);
    static final String dfa_1s = "\10\uffff";
    static final String dfa_2s = "\3\4\1\24\2\4\2\uffff";
    static final String dfa_3s = "\1\4\1\16\1\4\1\24\1\16\1\5\2\uffff";
    static final String dfa_4s = "\6\uffff\1\1\1\2";
    static final String dfa_5s = "\10\uffff}>";
    static final String[] dfa_6s = {
            "\1\1",
            "\1\3\11\uffff\1\2",
            "\1\4",
            "\1\5",
            "\1\3\11\uffff\1\2",
            "\1\7\1\6",
            "",
            ""
    };

    static final short[] dfa_1 = DFA.unpackEncodedString(dfa_1s);
    static final char[] dfa_2 = DFA.unpackEncodedStringToUnsignedChars(dfa_2s);
    static final char[] dfa_3 = DFA.unpackEncodedStringToUnsignedChars(dfa_3s);
    static final short[] dfa_4 = DFA.unpackEncodedString(dfa_4s);
    static final short[] dfa_5 = DFA.unpackEncodedString(dfa_5s);
    static final short[][] dfa_6 = unpackEncodedStringArray(dfa_6s);

    class DFA8 extends DFA {

        public DFA8(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 8;
            this.eot = dfa_1;
            this.eof = dfa_1;
            this.min = dfa_2;
            this.max = dfa_3;
            this.accept = dfa_4;
            this.special = dfa_5;
            this.transition = dfa_6;
        }
        public String getDescription() {
            return "575:2: (this_DataTypeProperty_0= ruleDataTypeProperty | this_EnumProperty_1= ruleEnumProperty )";
        }
    }
 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0000000000068802L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000000000001000L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x0000000000402000L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x0000000000004002L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x0000000000010002L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0000000000082000L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x0000000000200002L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x0000000000800000L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x0000000001001000L});
    public static final BitSet FOLLOW_15 = new BitSet(new long[]{0x0000000002000000L});
    public static final BitSet FOLLOW_16 = new BitSet(new long[]{0x0000000010000000L});
    public static final BitSet FOLLOW_17 = new BitSet(new long[]{0x0000000000002000L});
    public static final BitSet FOLLOW_18 = new BitSet(new long[]{0x0000000004000000L});
    public static final BitSet FOLLOW_19 = new BitSet(new long[]{0x0000000008002000L});
    public static final BitSet FOLLOW_20 = new BitSet(new long[]{0x0000000020000000L});

}